package com.example.diplomwork;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiplomWorkApplicationTests {

    @Test
    void contextLoads() {
    }

}
