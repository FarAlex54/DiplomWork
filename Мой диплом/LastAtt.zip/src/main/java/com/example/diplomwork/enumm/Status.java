package com.example.diplomwork.enumm;

public enum Status {
    Принят, Оформлен, Ожидает, Получен, Архив
}
