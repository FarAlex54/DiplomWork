package com.example.diplomwork.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.example.diplomwork.util")
public class SpringConfig {

}
